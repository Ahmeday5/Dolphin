export const environment = {
  production: false, // خليها true لما ترفع المشروع على السيرفر (production)

  firebase: {
    apiKey: 'AIzaSyAdUUJ5DpmRj4nZbyOOz05fvJ700TeRuog',
    authDomain: 'dolphein-29808.firebaseapp.com',
    projectId: 'dolphein-29808',
    storageBucket: 'dolphein-29808.firebasestorage.app',
    messagingSenderId: '723858166026',
    appId: '1:723858166026:web:17f6880ac819f386afaaf3',
    measurementId: 'G-HM0R0553L6',
  },
  googleMapsApiKey: 'AIzaSyCDGR13JUYALaR-uqXS9AE4ApjSnn1k-gc',
};
